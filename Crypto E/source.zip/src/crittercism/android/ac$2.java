// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package crittercism.android;

import java.util.concurrent.Executor;

// Referenced classes of package crittercism.android:
//            ac

static final class utor
    implements Executor
{

    public final void execute(Runnable runnable)
    {
    }

    utor()
    {
    }
}
