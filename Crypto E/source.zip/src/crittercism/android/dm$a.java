// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package crittercism.android;

import java.util.Date;

// Referenced classes of package crittercism.android:
//            dn, dm

final class <init>
    implements dn
{

    final dm a;

    public final Date a()
    {
        return new Date();
    }

    private (dm dm1)
    {
        a = dm1;
        super();
    }

    a(dm dm1, byte byte0)
    {
        this(dm1);
    }
}
