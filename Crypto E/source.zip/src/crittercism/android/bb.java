// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package crittercism.android;

import android.location.Location;

public final class bb
{

    private static Location a;

    public static Location a()
    {
        crittercism/android/bb;
        JVM INSTR monitorenter ;
        Location location = a;
        crittercism/android/bb;
        JVM INSTR monitorexit ;
        return location;
        Exception exception;
        exception;
        throw exception;
    }

    public static boolean b()
    {
        crittercism/android/bb;
        JVM INSTR monitorenter ;
        Location location = a;
        boolean flag;
        if (location != null)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        crittercism/android/bb;
        JVM INSTR monitorexit ;
        return flag;
        Exception exception;
        exception;
        throw exception;
    }
}
