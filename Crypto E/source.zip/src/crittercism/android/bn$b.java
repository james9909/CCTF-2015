// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package crittercism.android;


// Referenced classes of package crittercism.android:
//            bm, bn, at

public static final class 
    implements bm
{

    private Integer a;

    public final String a()
    {
        return "app_version_code";
    }

    public final volatile Object b()
    {
        return a;
    }

    public ()
    {
        a = null;
        bn.a();
        a = Integer.valueOf(bn.a().b);
    }
}
