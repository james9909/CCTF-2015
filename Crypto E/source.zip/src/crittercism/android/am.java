// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package crittercism.android;


// Referenced classes of package crittercism.android:
//            ak, ai, ag, af, 
//            al

public final class am extends ak
{

    public am(af af1)
    {
        super(af1);
    }

    protected final af g()
    {
        if (super.f)
        {
            return new ai(this);
        }
        if (super.d && super.e > 0)
        {
            return new ag(this, super.e);
        } else
        {
            super.a.b(a());
            return super.a.b();
        }
    }
}
