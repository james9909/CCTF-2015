// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package crittercism.android;


// Referenced classes of package crittercism.android:
//            cq, ay, df, cb, 
//            dc

final class it> extends cq
{

    final ay a;

    public final void a()
    {
        a.g.a().a(ay.a, cb.h.a(), cb.h.b());
    }

    (ay ay1)
    {
        a = ay1;
        super();
    }
}
