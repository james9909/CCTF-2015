// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package crittercism.android;

import org.json.JSONObject;

// Referenced classes of package crittercism.android:
//            bn

public static final class <init> extends <init>
{

    public final String a()
    {
        return "wifi";
    }

    public final volatile JSONObject c()
    {
        return super.c();
    }

    public ()
    {
        super(1);
    }
}
