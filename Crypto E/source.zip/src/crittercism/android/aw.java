// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package crittercism.android;


public interface aw
{

    public abstract String a(String s, String s1);

    public abstract void a(String s, String s1, int i);

    public abstract void a(String s, String s1, String s2);

    public abstract int b(String s, String s1);

    public abstract boolean c(String s, String s1);
}
