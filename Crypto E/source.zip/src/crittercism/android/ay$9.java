// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package crittercism.android;


// Referenced classes of package crittercism.android:
//            cq, ay, bj, c

final class nit> extends cq
{

    final c a;
    final ay b;

    public final void a()
    {
        b.m.a(a);
    }

    (ay ay1, c c)
    {
        b = ay1;
        a = c;
        super();
    }
}
