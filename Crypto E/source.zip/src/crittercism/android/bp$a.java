// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package crittercism.android;

import java.io.File;

// Referenced classes of package crittercism.android:
//            bw, bp, bh

public static final class  extends bw
{

    public final bh a(File file)
    {
        return new bp(file, (byte)0);
    }

    public ()
    {
    }
}
