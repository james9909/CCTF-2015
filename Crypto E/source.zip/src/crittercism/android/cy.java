// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package crittercism.android;

import java.util.HashMap;
import java.util.Map;

public final class cy
{

    private static Map a;

    static 
    {
        HashMap hashmap = new HashMap();
        a = hashmap;
        hashmap.put("com.amazon.venezia", new cx.a.a());
        a.put("com.android.vending", new cx.b.a());
    }
}
