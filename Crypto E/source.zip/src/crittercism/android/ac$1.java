// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package crittercism.android;

import java.io.FileDescriptor;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.SocketAddress;
import java.net.SocketImpl;

// Referenced classes of package crittercism.android:
//            ac

static final class  extends SocketImpl
{

    protected final void accept(SocketImpl socketimpl)
    {
    }

    protected final int available()
    {
        return 0;
    }

    protected final void bind(InetAddress inetaddress, int i)
    {
    }

    protected final void close()
    {
    }

    protected final void connect(String s, int i)
    {
    }

    protected final void connect(InetAddress inetaddress, int i)
    {
    }

    protected final void connect(SocketAddress socketaddress, int i)
    {
    }

    protected final void create(boolean flag)
    {
    }

    protected final FileDescriptor getFileDescriptor()
    {
        return null;
    }

    protected final InetAddress getInetAddress()
    {
        return null;
    }

    protected final InputStream getInputStream()
    {
        return null;
    }

    protected final int getLocalPort()
    {
        return 0;
    }

    public final Object getOption(int i)
    {
        return null;
    }

    protected final OutputStream getOutputStream()
    {
        return null;
    }

    protected final int getPort()
    {
        return 0;
    }

    protected final void listen(int i)
    {
    }

    protected final void sendUrgentData(int i)
    {
    }

    public final void setOption(int i, Object obj)
    {
    }

    protected final void setPerformancePreferences(int i, int j, int k)
    {
    }

    protected final void shutdownInput()
    {
    }

    protected final void shutdownOutput()
    {
    }

    protected final boolean supportsUrgentData()
    {
        return false;
    }

    public final String toString()
    {
        return null;
    }

    ()
    {
    }
}
