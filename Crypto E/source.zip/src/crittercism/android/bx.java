// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package crittercism.android;


public final class bx extends RuntimeException
{

    public bx(String s)
    {
        this(s, null);
    }

    public bx(String s, Throwable throwable)
    {
        super(s, throwable);
    }

    public bx(Throwable throwable)
    {
        super(throwable);
    }
}
