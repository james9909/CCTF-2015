// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package crittercism.android;


// Referenced classes of package crittercism.android:
//            au, ba, df

public final class az
    implements au
{

    private au a;
    private final String b;

    public az(au au1, ba ba1)
    {
        a = au1;
        b = ba1.m();
    }

    public final String a()
    {
        return b;
    }

    public final String b()
    {
        return a.b();
    }

    public final String c()
    {
        return a.c();
    }

    public final int d()
    {
        return a.d();
    }

    public final String e()
    {
        return a.e();
    }

    public final String f()
    {
        return a.f();
    }

    public final String g()
    {
        return a.g();
    }

    public final String h()
    {
        return a.h();
    }

    public final df i()
    {
        return a.i();
    }
}
