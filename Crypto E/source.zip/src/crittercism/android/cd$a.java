// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package crittercism.android;

import android.content.Context;

// Referenced classes of package crittercism.android:
//            ch, cd, bj, au, 
//            df, cg

public static final class 
    implements ch
{

    public final cg a(bj bj, bj bj1, String s, Context context, au au, df df)
    {
        return new cd(bj, bj1, s, context, au, df);
    }

    public ()
    {
    }
}
