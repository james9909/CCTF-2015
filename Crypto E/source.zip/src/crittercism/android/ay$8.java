// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package crittercism.android;


// Referenced classes of package crittercism.android:
//            cq, ay, bj, bt

public final class nit> extends cq
{

    final bt a;
    final ay b;

    public final void a()
    {
        b.l.a(a);
    }

    public (ay ay1, bt bt)
    {
        b = ay1;
        a = bt;
        super();
    }
}
