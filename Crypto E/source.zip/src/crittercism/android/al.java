// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package crittercism.android;


// Referenced classes of package crittercism.android:
//            af

public interface al
{

    public abstract af a();

    public abstract void a(int i);

    public abstract void a(af af);

    public abstract void a(String s);

    public abstract void a(String s, String s1);

    public abstract af b();

    public abstract void b(int i);

    public abstract String c();
}
