// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package crittercism.android;


// Referenced classes of package crittercism.android:
//            cq, ay, df, cn, 
//            ba

public final class  extends cq
{

    final ay a;

    public final void a()
    {
        if (a.g.c())
        {
            return;
        } else
        {
            cn cn1 = new cn(a.c);
            cn1.a(a.h, new <init>(), a.w.k(), ay.a);
            cn1.a(a.i, new <init>(), a.w.k(), ay.a);
            cn1.a(a.j, new <init>(), a.w.k(), ay.a);
            cn1.a(a.k, new <init>(), a.w.k(), ay.a);
            cn1.a(a.o, a.q);
            return;
        }
    }
}
