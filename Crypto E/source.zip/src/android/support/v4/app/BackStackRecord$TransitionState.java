// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.app;

import android.support.v4.util.ArrayMap;
import android.view.View;
import java.util.ArrayList;

// Referenced classes of package android.support.v4.app:
//            BackStackRecord

public class nterView
{

    public nterView enteringEpicenterView;
    public ArrayList hiddenFragmentViews;
    public ArrayMap nameOverrides;
    public View nonExistentView;
    final BackStackRecord this$0;

    public nterView()
    {
        this$0 = BackStackRecord.this;
        super();
        nameOverrides = new ArrayMap();
        hiddenFragmentViews = new ArrayList();
        enteringEpicenterView = new nterView();
    }
}
