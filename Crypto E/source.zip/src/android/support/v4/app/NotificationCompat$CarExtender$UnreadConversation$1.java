// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.app;

import android.app.PendingIntent;

// Referenced classes of package android.support.v4.app:
//            RemoteInput, NotificationCompat

static final class 
    implements 
{

    public  build(String as[],  , PendingIntent pendingintent, PendingIntent pendingintent1, String as1[], long l)
    {
        return new nit>(as, (RemoteInput), pendingintent, pendingintent1, as1, l);
    }

    public volatile nit> build(String as[], nit> nit>, PendingIntent pendingintent, PendingIntent pendingintent1, String as1[], long l)
    {
        return build(as, nit>, pendingintent, pendingintent1, as1, l);
    }

    ()
    {
    }
}
