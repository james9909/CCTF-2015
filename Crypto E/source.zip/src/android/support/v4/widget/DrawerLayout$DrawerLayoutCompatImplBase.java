// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.widget;

import android.view.View;

// Referenced classes of package android.support.v4.widget:
//            DrawerLayout

static class 
    implements 
{

    public void applyMarginInsets(android.view.mpatImplBase mpatimplbase, Object obj, int i)
    {
    }

    public void configureApplyInsets(View view)
    {
    }

    public void dispatchChildInsets(View view, Object obj, int i)
    {
    }

    public int getTopInset(Object obj)
    {
        return 0;
    }

    ()
    {
    }
}
