// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.widget;

import android.view.View;

// Referenced classes of package android.support.v4.widget:
//            DrawerLayoutCompatApi21, DrawerLayout

static class 
    implements 
{

    public void applyMarginInsets(android.view.patImplApi21 patimplapi21, Object obj, int i)
    {
        DrawerLayoutCompatApi21.applyMarginInsets(patimplapi21, obj, i);
    }

    public void configureApplyInsets(View view)
    {
        DrawerLayoutCompatApi21.configureApplyInsets(view);
    }

    public void dispatchChildInsets(View view, Object obj, int i)
    {
        DrawerLayoutCompatApi21.dispatchChildInsets(view, obj, i);
    }

    public int getTopInset(Object obj)
    {
        return DrawerLayoutCompatApi21.getTopInset(obj);
    }

    ()
    {
    }
}
